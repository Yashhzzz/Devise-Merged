document.addEventListener('DOMContentLoaded', () => {
  const logsContainer = document.getElementById('logs-container');

  // Load logs from storage
  chrome.storage.local.get({ userLogs: [] }, (result) => {
    const logs = result.userLogs;
    
    if (logs.length === 0) {
      logsContainer.innerHTML = '<div class="empty-state">No AI tools detected yet.</div>';
      return;
    }

    logsContainer.innerHTML = ''; // Clear empty state
    
    // Show top 10 logs
    const displayLogs = logs.slice(0, 10);
    
    displayLogs.forEach(entry => {
      const date = new Date(entry.timestamp);
      // Format time: HH:MM AM/PM
      const timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const logEl = document.createElement('div');
      logEl.className = 'log-entry';
      logEl.innerHTML = `
        <div class="log-left">
          <span class="log-tool">${entry.toolName}</span>
          <span class="log-domain">Session Block</span>
        </div>
        <div class="log-time">${timeString}</div>
      `;
      logsContainer.appendChild(logEl);
    });
  });
});
