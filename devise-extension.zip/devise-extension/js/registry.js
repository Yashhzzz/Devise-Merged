// registry.js
// A lightweight map of known AI tools for tracking
const AI_REGISTRY = {
  "chatgpt.com": { id: "openai_chatgpt", name: "ChatGPT", category: "Chat AI" },
  "claude.ai": { id: "anthropic_claude", name: "Claude", category: "Chat AI" },
  "gemini.google.com": { id: "google_gemini", name: "Gemini", category: "Chat AI" },
  "poe.com": { id: "quora_poe", name: "Poe", category: "Chat AI" },
  "perplexity.ai": { id: "perplexity", name: "Perplexity", category: "AI Search" },
  "midjourney.com": { id: "midjourney", name: "Midjourney", category: "Image Gen" },
  "github.com/copilot": { id: "github_copilot", name: "GitHub Copilot", category: "Coding AI" },
  "huggingface.co": { id: "hugging_face", name: "Hugging Face", category: "AI Hub" }
};

export { AI_REGISTRY };
