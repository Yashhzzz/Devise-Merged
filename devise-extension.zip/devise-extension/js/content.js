// js/content.js
// Injects the Prompt Enhancement button into known AI tools

console.log("[Devise] Content script injected.");

let buttonInjected = false;

// Create the Devise trigger UI wrapper
function createDeviseUI() {
  const container = document.createElement('div');
  container.id = 'devise-ui-container';
  container.style.display = 'inline-flex';
  container.style.position = 'relative'; 
  container.style.alignItems = 'center'; 
  container.style.justifyContent = 'center';
  container.style.margin = '4px 8px 0 0'; // Added top margin to pull it down slightly
  container.style.zIndex = '2147483647';

  const btn = document.createElement('button');
  btn.id = 'devise-enhance-btn';
  btn.style.display = 'flex';
  btn.style.alignItems = 'center';
  btn.style.justifyContent = 'center';
  btn.style.gap = '4px';
  btn.style.padding = '0 12px';
  btn.style.height = '32px'; 
  btn.style.whiteSpace = 'nowrap';
  btn.style.flexShrink = '0';
  btn.style.background = '#3b82f6';
  btn.style.color = '#fff';
  btn.style.border = 'none';
  btn.style.borderRadius = '16px'; 
  btn.style.fontSize = '12px'; 
  btn.style.fontWeight = '600';
  btn.style.cursor = 'pointer';
  btn.style.boxShadow = '0 2px 5px rgba(0,0,0,0.15)';
  btn.style.transition = 'all 0.2s';
  btn.style.zIndex = '2147483647';
  btn.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
    </svg>
    <span>Auto-Enhance ▼</span>
  `;
  
  // Toggle the global modal on main button click
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    openDeviseModal(btn);
  });

  container.appendChild(btn);
  
  return container;
}

// Global modal injection to escape ALL layout clipping constraints
function openDeviseModal(triggerBtn) {
  let modal = document.getElementById('devise-skill-modal');
  
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'devise-skill-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    modal.style.background = 'rgba(0,0,0,0.4)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.zIndex = '2147483647'; // Maximum possible z-index
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';

    const modalContent = document.createElement('div');
    modalContent.style.background = '#1f2937';
    modalContent.style.padding = '24px';
    modalContent.style.borderRadius = '16px';
    modalContent.style.boxShadow = '0 10px 25px rgba(0,0,0,0.5)';
    modalContent.style.minWidth = '300px';
    modalContent.style.border = '1px solid rgba(255,255,255,0.1)';

    const header = document.createElement('h3');
    header.textContent = 'Select AI Skill';
    header.style.color = '#fff';
    header.style.margin = '0 0 16px 0';
    header.style.fontSize = '18px';
    header.style.fontWeight = '600';
    modalContent.appendChild(header);

    const skills = [
      { id: 'auto', label: '✨ Auto-Detect' },
      { id: 'ui-ux', label: '🎨 UI/UX Pro Max' },
      { id: 'marketing', label: '📈 Marketing Pro' },
      { id: 'finance', label: '💼 Finance Pro' },
      { id: 'prototype', label: '🚀 Prototype Pro' }
    ];

    skills.forEach(skill => {
      const btn = document.createElement('button');
      btn.textContent = skill.label;
      btn.style.display = 'block';
      btn.style.width = '100%';
      btn.style.padding = '12px 16px';
      btn.style.marginBottom = '8px';
      btn.style.background = 'rgba(255,255,255,0.05)';
      btn.style.color = '#fff';
      btn.style.border = '1px solid rgba(255,255,255,0.1)';
      btn.style.borderRadius = '8px';
      btn.style.fontSize = '14px';
      btn.style.fontWeight = '500';
      btn.style.cursor = 'pointer';
      btn.style.textAlign = 'left';
      btn.style.transition = 'all 0.2s';
      
      btn.addEventListener('mouseenter', () => {
         btn.style.background = 'rgba(59,130,246,0.2)';
         btn.style.borderColor = '#3b82f6';
      });
      btn.addEventListener('mouseleave', () => {
         btn.style.background = 'rgba(255,255,255,0.05)';
         btn.style.borderColor = 'rgba(255,255,255,0.1)';
      });
      
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        modal.style.display = 'none';
        triggerEnhancement(skill.id, triggerBtn);
      });
      
      modalContent.appendChild(btn);
    });

    const closeBtn = document.createElement('button');
    closeBtn.textContent = 'Cancel';
    closeBtn.style.display = 'block';
    closeBtn.style.width = '100%';
    closeBtn.style.padding = '10px';
    closeBtn.style.marginTop = '16px';
    closeBtn.style.background = 'transparent';
    closeBtn.style.color = '#9ca3af';
    closeBtn.style.border = 'none';
    closeBtn.style.cursor = 'pointer';
    closeBtn.style.fontSize = '14px';
    
    closeBtn.addEventListener('click', (e) => {
       e.stopPropagation();
       modal.style.display = 'none';
    });
    
    modalContent.appendChild(closeBtn);
    modal.appendChild(modalContent);

    // Close on background click
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    });

    // Append directly to the body to escape ALL layout styling of the current page
    document.body.appendChild(modal);
  }

  // Update logic to retain reference to the button that was clicked
  modal.style.display = 'flex';
}

function triggerEnhancement(skillId, btnElement) {
  const textareaElement = findTextarea();
  if (textareaElement) {
    const currentText = getText(textareaElement);
    if (currentText && currentText.trim().length > 0) {
      const originalHtml = btnElement.innerHTML;
      btnElement.innerHTML = `<span>Enhancing...</span>`;
      btnElement.style.opacity = '0.7';

      chrome.runtime.sendMessage({ action: 'enhance', text: currentText, hostname: window.location.hostname, skill: skillId }, (response) => {
        if (response && response.success) {
          setText(textareaElement, response.enhancedText);
          btnElement.innerHTML = `<span>Enhanced! ✨</span>`;
          btnElement.style.background = "linear-gradient(135deg, #3b82f6, #2563eb)";
        } else {
          console.error("[Devise] Auto-enhance error:", response?.error);
          alert("Devise Enhancement Failed: " + (response?.error || 'Unknown error'));
          btnElement.innerHTML = `<span>Failed ❌</span>`;
          btnElement.style.background = "#ef4444";
        }
        
        btnElement.style.opacity = '1';
        setTimeout(() => {
          btnElement.innerHTML = originalHtml;
          btnElement.style.background = ""; // reset
        }, 3000);
      });
    }
  }
}

function findTextarea() {
  const hostname = window.location.hostname;
  
  if (hostname.includes("gemini.google.com")) {
    const editor = document.querySelector('.ql-editor'); // Gemini uses Quill under rich-textarea
    if (editor) return editor;
    return document.querySelector('rich-textarea'); // Fallback
  }
  
  if (hostname.includes("claude.ai")) {
    const pm = document.querySelector('.ProseMirror'); // Claude uses ProseMirror
    if (pm) return pm;
  }

  let textarea = document.getElementById('prompt-textarea');
  if (!textarea) {
    const textareas = document.querySelectorAll('textarea');
    if (textareas.length > 0) {
       textarea = textareas[textareas.length - 1]; 
    } else {
       const editables = document.querySelectorAll('[contenteditable="true"]');
       if (editables.length > 0) textarea = editables[editables.length - 1];
    }
  }
  return textarea;
}

function getText(element) {
  if (element.tagName.toLowerCase() === 'textarea') {
    return element.value;
  } else if (element.hasAttribute('contenteditable')) {
    return element.innerText;
  }
  return "";
}

function setText(element, text) {
  if (element.tagName.toLowerCase() === 'textarea') {
    element.value = text;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  } else if (element.hasAttribute('contenteditable')) {
    element.innerText = text;
    // Clear out other nodes, just append the text
    element.innerHTML = '';
    const textNode = document.createTextNode(text);
    element.appendChild(textNode);
    element.dispatchEvent(new Event('input', { bubbles: true }));
  }
}

function simulateSubmit(element) {
  // First, explicitly click the send button if we can find it
  const parentContainer = element.closest('form') || element.closest('div[class*="composer"]') || document.body;
  let button = parentContainer.querySelector('button[data-testid="send-button"], button[aria-label*="Send"], button[aria-label*="send"]');
  
  if (button && !button.disabled) {
    button.click();
  } else {
    // Dispatch Enter key as a fallback
    const enterEvent = new KeyboardEvent('keydown', {
      bubbles: true,
      cancelable: true,
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13
    });
    element.dispatchEvent(enterEvent);
  }
}

// Observer to wait for the page layout (since these are SPAs)
function observeAndInject() {
  const observer = new MutationObserver((mutations) => {
    if (buttonInjected) return;
    
    const hostname = window.location.hostname;
    let targetContainer = null;

    if (hostname.includes("chatgpt.com")) {
      // The most reliable way in ChatGPT is to find the Send/Voice button container next to the textarea
      const textarea = findTextarea();
      if (textarea) {
        // Find the wrapper holding the submit/mic buttons next to the textarea
        const parentForm = textarea.closest('form') || textarea.closest('div[class*="composer"]');
        if (parentForm) {
          const sendBtnWrap = parentForm.querySelector('button[data-testid="send-button"]')?.parentElement;
          if (sendBtnWrap) {
               targetContainer = sendBtnWrap.parentElement; // The flex row holding the buttons
          } else {
               // Fallback: Just drop it at the bottom of the composer
               targetContainer = parentForm;
               containerStyleOverwrite = true;
          }
        }
      }
    } else if (hostname.includes("claude.ai")) {
      const editables = document.querySelectorAll('[contenteditable="true"]');
      if (editables.length > 0) {
         const p = editables[editables.length - 1].parentElement;
         if (p && p.parentElement) targetContainer = p.parentElement;
      }
    } else if (hostname.includes("gemini.google.com")) {
      const richText = document.querySelector('rich-textarea');
      if (richText) targetContainer = richText.parentElement;
    } else {
      const bottomBars = document.querySelectorAll('form');
      if (bottomBars.length > 0) {
        targetContainer = bottomBars[bottomBars.length - 1];
      }
    }

    if (targetContainer) {
      if (!document.getElementById('devise-enhance-btn')) {
        const uiContainer = createDeviseUI();
        
        // If we are injecting into an unknown layout block, give it absolute positioning as a fallback
        if (typeof containerStyleOverwrite !== 'undefined' && containerStyleOverwrite) {
           uiContainer.style.position = 'absolute';
           uiContainer.style.bottom = '100%';
           uiContainer.style.right = '0';
           uiContainer.style.marginBottom = '12px';
        }
        
        targetContainer.style.position = 'relative'; 
        
        // If we are in ChatGPT's button row, we want it to prepend so it sits left of the send button
        if (hostname.includes("chatgpt.com")) {
           uiContainer.style.transform = "translateY(6px)"; // Micro-adjustment to center perfectly alongside the mic icon
           targetContainer.insertBefore(uiContainer, targetContainer.firstChild);
        } else {
           targetContainer.appendChild(uiContainer);
        }

        buttonInjected = true;
        observer.disconnect(); 
        console.log("[Devise] Auto-Enhance button injected.");
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// Kickoff
setTimeout(observeAndInject, 1000);
