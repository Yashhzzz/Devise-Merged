// background.js
// The Devise Service Worker: Runs silently and logs tool usage.

import { AI_REGISTRY } from './registry.js';

// We'll store a mock user until the login flow is complete
const MOCK_USER_ID = "emp_1001";
const DEV_DASHBOARD_URL = "https://devise-iris.vercel.app/api/ingest"; 

// Track active sessions to prevent spamming logs
let activeSessions = new Map();

// Helper to extract hostname from URL
function getHostname(urlStr) {
  try {
    const url = new URL(urlStr);
    return url.hostname;
  } catch (e) {
    return null;
  }
}

// Function to log the usage metadata
async function logAIUsage(toolId, toolName, url) {
  const timestamp = new Date().toISOString();
  
  // Create metadata payload
  const logEntry = {
    userId: MOCK_USER_ID,
    toolId: toolId,
    toolName: toolName,
    sourceApp: "chrome.exe", // Extension context
    timestamp: timestamp,
    // Note: No prompts, no data, just metaphysical access data
  };

  console.log("[Devise Tracker]", logEntry);

  // Save to local storage so the popup can show history
  chrome.storage.local.get({ userLogs: [] }, (result) => {
    const updatedLogs = [logEntry, ...result.userLogs].slice(0, 100); // Keep last 100
    chrome.storage.local.set({ userLogs: updatedLogs });
  });

  // Future Dashboard Sync:
  /*
  try {
    await fetch(DEV_DASHBOARD_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(logEntry)
    });
  } catch (e) {
    console.error("Dashboard sync failed", e);
  }
  */
}

// Listen to web navigation commitments (top-frame only)
chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return; // Only track main frame

  const hostname = getHostname(details.url);
  if (!hostname) return;

  // Check if domain matches any in registry
  // We check if the hostname ends with any known domain
  let matchedTool = null;
  for (const [domain, toolInfo] of Object.entries(AI_REGISTRY)) {
    if (hostname === domain || hostname.endsWith("." + domain)) {
      matchedTool = toolInfo;
      break;
    }
  }

  if (matchedTool) {
    // Only log if we haven't logged this tab recently
    const sessionKey = `${details.tabId}_${matchedTool.id}`;
    const lastLogged = activeSessions.get(sessionKey);
    const now = Date.now();
    
    // If not logged in last 10 minutes, log it
    if (!lastLogged || (now - lastLogged > 10 * 60 * 1000)) {
      activeSessions.set(sessionKey, now);
      logAIUsage(matchedTool.id, matchedTool.name, details.url);
    }
  }
});

// Cleanup inactive tabs
chrome.tabs.onRemoved.addListener((tabId) => {
  // Find and remove any sessions for this tab
  for (const key of activeSessions.keys()) {
    if (key.startsWith(`${tabId}_`)) {
      activeSessions.delete(key);
    }
  }
});

// Listen for auto-enhance requests from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'enhance') {
    handleEnhanceProxy(request.text, request.hostname, request.skill).then(sendResponse);
    return true; // Indicates asynchronous response
  }
});

async function handleEnhanceProxy(text, hostname, skill) {
  try {
    const { geminiApiKey } = await chrome.storage.local.get(['geminiApiKey']);
    if (!geminiApiKey) {
      return { error: 'No API key configured. Please set your Gemini API key in the Devise Extension Options.' };
    }

    let platform = "an advanced AI model";
    if (hostname) {
      if (hostname.includes('chatgpt')) platform = "ChatGPT (OpenAI)";
      else if (hostname.includes('claude')) platform = "Claude (Anthropic)";
      else if (hostname.includes('gemini.google')) platform = "Gemini (Google)";
      else if (hostname.includes('poe')) platform = "Poe AI";
    }

    let skillInstruction = "";
    let appliedSkill = skill;

    if (!appliedSkill || appliedSkill === 'auto') {
      const lowerText = text.toLowerCase();
      if (lowerText.includes('react') || lowerText.includes('html') || lowerText.includes('css') || lowerText.includes('ui') || lowerText.includes('ux') || lowerText.includes('design') || lowerText.includes('component')) {
        appliedSkill = 'ui-ux';
      } else if (lowerText.includes('copy') || lowerText.includes('seo') || lowerText.includes('marketing') || lowerText.includes('audience') || lowerText.includes('campaign') || lowerText.includes('conversion')) {
        appliedSkill = 'marketing';
      } else if (lowerText.includes('finance') || lowerText.includes('revenue') || lowerText.includes('q1') || lowerText.includes('q2') || lowerText.includes('q3') || lowerText.includes('q4') || lowerText.includes('$') || lowerText.includes('earnings') || lowerText.includes('stock')) {
        appliedSkill = 'finance';
      } else if (lowerText.includes('prototype') || lowerText.includes('mvp') || lowerText.includes('mock') || lowerText.includes('proof of concept') || lowerText.includes('scaffold')) {
        appliedSkill = 'prototype';
      } else {
        appliedSkill = 'general';
      }
    }

    if (appliedSkill === 'ui-ux') {
      skillInstruction = `You are a world-class AI prompt engineer armed with the "UI/UX Pro Max Intelligence Engine". 
Your objective is to take the user's short input and transform it into a massive, rigorous prompt optimized for ${platform}. 

If the user's request involves UI, Frontend, Design, or Web layouts, you MUST aggressively inject the following "UI/UX Pro Max" intelligence rules into your enhanced prompt to force the AI to write enterprise-grade code.

### The UI/UX Pro Max Injection Rules (Force the AI to follow these):
1. **Visual Quality:** Absolutely NO emojis as UI icons. Force the AI to use modern Tailwind utility classes.
2. **Interaction:** Force \`cursor-pointer\` on all interactables. Force smooth hover states.
3. **Typography & Colors:** Force the AI to select a premium Google Font. Use high-contrast text.
4. **Layout:** Force the AI to use proper responsive grid/flex layouts with clean spacing. 
5. **Modern Aesthetics:** Force the AI to try and implement sleek visual flair (Glassmorphism, etc.).

### Framework to Build the Output Prompt:
1. **Context & Goal:** Expand the user's vague query into a professional, component-based request.
2. **The Constraints:** Explicitly list the rules above as MUST-HAVES in the AI's final code.
3. **Execution Plan:** Tell the AI to output exactly what UI components it will build before writing code.
4. **Output Format:** Force the AI to provide single-file artifacts that are copy-paste ready.`;
    } else if (appliedSkill === 'marketing') {
      skillInstruction = `You are a top-tier Marketing Copywriter and SEO tactician.
Your objective is to take the user's short input and transform it into a highly optimized marketing prompt for ${platform}.

### Marketing Pro Rules:
1. **Frameworks:** Force the AI to use proven copywriting frameworks (AIDA, PAS).
2. **SEO Optimization:** Instruct the AI to seamlessly weave semantic keywords.
3. **Conversion Focus:** Demand strong Call to Actions (CTAs) and benefit-driven language.
4. **Tone:** Specify a tone that is persuasive and authoritative.

### Framework to Build the Output Prompt:
1. **Target Audience:** Tell the AI to clearly define the audience it is writing for.
2. **Core Message:** Expand the user's input into the primary value proposition.
3. **Copy Structure:** Demand a structure with catchy headlines and compelling bullets.`;
    } else if (appliedSkill === 'finance') {
      skillInstruction = `You are an elite Financial Analyst paired with a Data Redaction Engine.
Your objective is to take the user's input, REDACT any sensitive data, and then build a massive, rigorous financial analysis prompt for ${platform}.

### CRITICAL REDACTION STEP (MUST DO THIS FIRST):
Before creating the prompt, you MUST sanitize the user's input. Identify real company names, actual revenue figures, specific dates, or internal IDs, and replace them with generic tags (e.g., [COMPANY_A], [REDACTED_AMOUNT]). Do NOT include the real company name or numbers in the final enhanced prompt.

### Finance Pro Rules:
1. **Analytical Depth:** Force the AI to perform deep dive analysis based on the sanitized data.
2. **Structuring Data:** Instruct the AI to output findings in clean markdown tables.
3. **Risk & Scenarios:** Demand the AI provide bull, bear, and base case scenarios.

### Framework to Build the Output Prompt:
1. **Sanitized Context:** Present the fully sanitized data to the model.
2. **Analysis Required:** Explicitly demand the analytical frameworks.
3. **Actionable Insights:** Tell the AI to conclude with data-driven strategic options.`;
    } else if (appliedSkill === 'prototype') {
      skillInstruction = `You are an expert Rapid Prototyper.
Your objective is to take the user's short input and transform it into a rigorous prompt optimized for ${platform} to build a functional prototype.

### Prototype Pro Rules:
1. **Minimal Workable Code:** Force the AI to prioritize functional completion over edge-case handling.
2. **Mock Data:** Instruct the AI to explicitly generate robust mock data scaffolding.
3. **No Setup Hassle:** Demand the AI uses CDNs for libraries so it runs in a single HTML file.

### Framework to Build the Output Prompt:
1. **MVP Scope:** Expand the user's request into a strict list of 3-4 core features.
2. **Tech Stack Constraints:** Tell the AI to use zero-build-step technologies.
3. **Architecture:** Demand the AI structures the single-file code cleanly with clear comments.`;
    } else {
      skillInstruction = `You are a world-class AI prompt engineer.
Your objective is to take the user's short input and transform it into an incredibly detailed, highly effective prompt optimized for ${platform}.`;
    }

    const systemInstruction = `${skillInstruction}

Output ONLY the final, brutally strict, incredibly detailed enhanced prompt text. No introductory filler.

User's Original Input:
${text}`;

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiApiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: systemInstruction
          }]
        }]
      })
    });

    const data = await response.json();
    if (data.error) {
       return { error: data.error.message || 'API Error' };
    }
    const enhancedText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (enhancedText) {
      return { success: true, enhancedText };
    }
    return { error: 'Unexpected response from Gemini API.' };
  } catch (err) {
    return { error: err.message };
  }
}
